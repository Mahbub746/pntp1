<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<header>
										<h3><a href="#">Categories</a></h3>
									</header>
<ul style="list-style: none;">
										<?php
										$categories=$obj->getCategories("categories","*","status='publish'");

								foreach($categories as $category){

									echo "<li><a href=\"i.php?cat_id=$category[cat_id]\">$category[name]</a></li>";
											}
										?>
									</ul>
</body>
</html>