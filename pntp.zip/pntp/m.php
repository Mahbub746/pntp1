								<article id="main">
							
									<section>
						<?php
						if(isset($_REQUEST['cat_id'])){
							$cat_id=$_REQUEST['cat_id'];
							$posts=$obj->getCategories("posts","*","cat_id=$cat_id AND status='publish'");
							foreach($posts as $post){
								extract($post);
?>
<header>
											<h3><?=$title;?></h3>
										</header>
										<?php
					if(str_word_count($content)>30){
						$strToArray=explode(" ", $content);
						$newContent=array_slice($strToArray, 0,30);
						echo implode(" ", $newContent);

					}
										?>
										<a href="i.php?art_id=<?=$art_id;?>">Read more...</a>
										<?php
}
						}
						?>

												<?php
						if(isset($_REQUEST['art_id'])){
							$art_id=$_REQUEST['art_id'];
							$posts=$obj->getCategories("posts","*","art_id=$art_id AND status='publish'");
							foreach($posts as $post){
								extract($post);
?>
<header>
											<h3><?=$title;?></h3>
										</header>
										
					<?=$content;?>
										
									<?php
									}
								}
									?>	
									</section>

								</article>