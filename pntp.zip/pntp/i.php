<?php
include "db.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<?php
include "m.php";
?>
<?php
include "sb.php";
?>


</body>
</html>